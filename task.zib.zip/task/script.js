let name = prompt("Enter Your Name");
let age = prompt("Enter Your Age");
let city = prompt("Enter Your City");

document.getElementById("userData").innerHTML =
    "My Name Is: " + name + "<br>" +
    "My Age Is: " + age + "<br>" +
    "My City Is: " + city;